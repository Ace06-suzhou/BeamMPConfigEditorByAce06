
using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace BeamMPConfigEditorByAce06
{
    public partial class Form1 : Form
    {
        // ���ü� + ����ע�ͣ������Զ�����ע�ͣ�
        private readonly Dictionary<string, string> configHelp = new()
        {
            { "Name", "���������ƣ���ʾ�ڷ������б��е�����" },
            { "Description", "�������������б��е���ϸ����" },
            { "Port", "�������˿ڣ�Ĭ�� 30814����˿�ת��" },
            { "AuthKey", "��֤��Կ���� https://keymaster.beammp.com ��ȡ������" },
            { "Map", "��ͼ·�������� \"/levels/gridmap_v2/info.json\"" },
            { "MaxPlayers", "�������������� 8~128�����ݷ���������" },
            { "MaxCars", "ÿ��������������� 1~5" },
            { "Private", "˽�з�������true=��������ʾ" },
            { "Debug", "����ģʽ��true=���������־" },
            { "LogChat", "��¼���죺true=�ڿ���̨��ʾ��������" },
            { "Tags", "��ǩ���ö��ŷָ����� \"Freeroam, Drift\"" },
            { "ResourceFolder", "��Դ�ļ��У�ģ�����Դ�Ĵ洢·��" },
            { "AllowGuests", "�Ƿ������οͼ��룺true/false" },
            { "ImScaredOfUpdates", "�Ƿ���ø�����ʾ��true/false�����Ƽ����ڿ�����" },
            { "SendErrors", "�Ƿ��ʹ��󱨸�������ߣ�true/false" },
            { "SendErrorsShowMessage", "����ʱ�Ƿ���ʾ���󱨸���ʾ��true/false" },
        };

        // ���ݼ��Ƽ��ĳ���ֵ������ TAB ��ȫ��
        private readonly Dictionary<string, string[]> valueSuggestions = new()
        {
            { "Private", new[] { "true", "false" } },
            { "Debug", new[] { "true", "false" } },
            { "LogChat", new[] { "true", "false" } },
            { "AllowGuests", new[] { "true", "false" } },
            { "ImScaredOfUpdates", new[] { "true", "false" } },
            { "SendErrors", new[] { "true", "false" } },
            { "SendErrorsShowMessage", new[] { "true", "false" } },
            { "MaxPlayers", new[] { "8", "10", "12", "16", "24", "32", "48", "64", "96", "128" } },
            { "MaxCars", new[] { "1", "2", "3", "4", "5", "6", "8", "10" } },
            { "Port", new[] { "30814", "30815", "30816", "30817" } },
            { "Map", new[]
                {
                    "/levels/gridmap_v2/info.json",
                    "/levels/italy/info.json",
                    "/levels/east_coast_usa/info.json",
                    "/levels/west_coast_usa/info.json",
                    "/levels/japan/info.json",
                    "/levels/hirochi_raceway/info.json"
                }
            },
            { "Tags", new[]
                {
                    "Freeroam", "Drift", "Racing", "Roleplay", "Cruise", "Derby",
                    "Chinese", "����", "����", "Realistic", "Simulation"
                }
            }
        };

        private string currentFilePath = null;

        // ���� TAB ��ȫѭ�������ֶΣ���� static �ֲ���������
        private int lastTabIndex = -1;
        private string lastTabWord = "";

        public Form1()
        {
            InitializeComponent();
            this.Text = "BeamMP ServerConfig.toml �༭��";

            // ��ʼ�� RichTextBox ���ԣ���������û���ã�
            rtbEditor.Font = new Font("Consolas", 10f);
            rtbEditor.AcceptsTab = true;
            rtbEditor.WordWrap = false;
            rtbEditor.ScrollBars = RichTextBoxScrollBars.Both;
        }

        // �˵��¼����½�
        private void newToolStripMenuItem_Click(object sender, EventArgs e)
        {
            rtbEditor.Clear();
            currentFilePath = null;
            this.Text = "BeamMP ServerConfig.toml �༭�� - �½��ļ�";
        }

        // �˵��¼�����
        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            using OpenFileDialog ofd = new()
            {
                Filter = "TOML �ļ� (*.toml)|*.toml|�����ļ� (*.*)|*.*",
                Title = "�� ServerConfig.toml"
            };

            if (ofd.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    currentFilePath = ofd.FileName;
                    rtbEditor.Text = File.ReadAllText(currentFilePath);
                    this.Text = $"BeamMP ServerConfig.toml �༭�� - {Path.GetFileName(currentFilePath)}";
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"���ļ�ʧ�ܣ�{ex.Message}", "����", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        // �˵��¼�������
        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(currentFilePath))
            {
                saveAsToolStripMenuItem_Click(sender, e);
                return;
            }

            try
            {
                File.WriteAllText(currentFilePath, rtbEditor.Text);
                MessageBox.Show("�ѱ���", "��ʾ", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"����ʧ�ܣ�{ex.Message}", "����", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // �˵��¼�������Ϊ
        private void saveAsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            using SaveFileDialog sfd = new()
            {
                Filter = "TOML �ļ� (*.toml)|*.toml|�����ļ� (*.*)|*.*",
                FileName = "ServerConfig.toml"
            };

            if (sfd.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    currentFilePath = sfd.FileName;
                    File.WriteAllText(currentFilePath, rtbEditor.Text);
                    this.Text = $"BeamMP ServerConfig.toml �༭�� - {Path.GetFileName(currentFilePath)}";
                    MessageBox.Show("�ѱ���", "��ʾ", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"����ʧ�ܣ�{ex.Message}", "����", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        // TAB �Զ���ȫ������ + ֵ����ѭ�� + ��궨λ��
        private void rtbEditor_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Tab)
            {
                e.SuppressKeyPress = true;
                e.Handled = true;

                int pos = rtbEditor.SelectionStart;
                string fullText = rtbEditor.Text;
                string currentLine = GetCurrentLine(fullText, pos).Trim();

                // ��ȡ��ǰ��
                string currentWord = GetLastWord(currentLine);

                // �Ƿ���ֵ����
                bool isInValue = currentLine.Contains("=");

                string key = isInValue ? ExtractKey(currentLine) : null;

                // ��ѡ�б�
                List<string> candidates = new List<string>();

                if (!isInValue)
                {
                    candidates = configHelp.Keys.Where(k => k.StartsWith(currentWord, StringComparison.OrdinalIgnoreCase)).ToList();
                }
                else if (key != null && valueSuggestions.TryGetValue(key, out var suggestions))
                {
                    string valuePart = currentLine.Substring(currentLine.IndexOf('=') + 1).Trim();
                    string input = valuePart.TrimStart('"').TrimEnd('"').Trim();
                    candidates = suggestions.Where(s => s.StartsWith(input, StringComparison.OrdinalIgnoreCase)).ToList();
                }

                if (candidates.Count == 0) return;

                // ѭ��ѡ��ʹ�����ֶμ�ס״̬��
                if (currentWord != lastTabWord)
                {
                    lastTabIndex = -1;
                    lastTabWord = currentWord;
                }
                lastTabIndex = (lastTabIndex + 1) % candidates.Count;
                string selected = candidates[lastTabIndex];

                // ��������
                string toInsert = selected;
                if (!isInValue)
                {
                    toInsert += " = ";
                }
                else if (key == "Map" || key == "Name" || key == "Description" || key == "Tags")
                {
                    toInsert = $"\"{selected}\"";
                }

                ReplaceCurrentWord(toInsert);

                // ��궨λ
                int newPos = rtbEditor.SelectionStart;
                if (!isInValue)
                {
                    // �ƶ��� = ����Ŀո��
                    newPos = rtbEditor.SelectionStart;  // ֱ���� = ��
                }
                rtbEditor.SelectionStart = newPos;
                rtbEditor.SelectionLength = 0;
            }
        }

        // �س�����ע��
        private void rtbEditor_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter || e.KeyCode == Keys.Return)
            {
                int pos = rtbEditor.SelectionStart;
                string fullText = rtbEditor.Text;
                string currentLine = GetCurrentLine(fullText, pos - 1);

                string key = ExtractKey(currentLine);
                if (!string.IsNullOrEmpty(key) && configHelp.TryGetValue(key, out string commentText))
                {
                    string prevLines = GetPreviousLines(fullText, pos, 5);
                    if (!prevLines.Contains($"# {key}:"))
                    {
                        string comment = $"# {key}: {commentText}\n";
                        rtbEditor.Text = rtbEditor.Text.Insert(pos - currentLine.Length - 1, comment);
                        rtbEditor.SelectionStart = pos + comment.Length;
                    }
                }
            }
        }

        // ��������
        private string GetCurrentLine(string text, int pos)
        {
            int start = text.LastIndexOf('\n', pos - 1) + 1;
            if (start < 0) start = 0;
            int end = text.IndexOf('\n', pos);
            if (end < 0) end = text.Length;
            return text.Substring(start, end - start);
        }

        private string GetPreviousLines(string text, int pos, int lineCount)
        {
            int count = 0;
            int start = pos;
            while (count < lineCount && start > 0)
            {
                start = text.LastIndexOf('\n', start - 1);
                if (start < 0) { start = 0; break; }
                count++;
            }
            return text.Substring(start, pos - start);
        }

        private string ExtractKey(string line)
        {
            if (string.IsNullOrWhiteSpace(line)) return null;
            int eqIndex = line.IndexOf('=');
            if (eqIndex <= 0) return null;
            return line.Substring(0, eqIndex).Trim();
        }

        private string GetLastWord(string line)
        {
            line = line.TrimEnd();
            int lastSpace = line.LastIndexOf(' ');
            return lastSpace >= 0 ? line.Substring(lastSpace + 1) : line;
        }

        private void ReplaceCurrentWord(string newWord)
        {
            int pos = rtbEditor.SelectionStart;
            string text = rtbEditor.Text;
            int start = pos;
            while (start > 0 && !char.IsWhiteSpace(text[start - 1]))
                start--;

            rtbEditor.Text = text.Substring(0, start) + newWord + text.Substring(pos);
            rtbEditor.SelectionStart = start + newWord.Length;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
